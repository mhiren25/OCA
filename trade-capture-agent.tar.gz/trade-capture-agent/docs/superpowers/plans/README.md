Superpowers writes plans here as `YYYY-MM-DD-<feature-name>.md`.

A plan implements **one** OpenSpec change — its header links back to that
change directory and copies the global constraints verbatim. Each task names
its files, its interfaces (what it consumes from earlier tasks and produces
for later ones), and five micro-steps: write failing test, verify it fails,
implement, verify it passes, commit.

Plans are committed because they record how a change was built. They are
**not** governance artifacts: nobody approves a plan, and a wrong one gets
regenerated rather than debated. Approval attaches to the change
(`approval.yaml`), never to the plan.
