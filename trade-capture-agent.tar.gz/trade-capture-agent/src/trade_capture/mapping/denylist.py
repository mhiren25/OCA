"""Fields the agent must never write.

This module is the mechanical enforcement of the draft-only invariant. The
agent cannot submit an order because it cannot write the field that would
allow it - not as a policy, as a property of the code.

Covered by CODEOWNERS. Changes need a named human approver.
"""

from __future__ import annotations

from typing import Any

DENIED_FIELDS: frozenset[str] = frozenset(
    {
        # Lifecycle - canSubmit above all. This is the invariant.
        "lifecycleData",
        # Service-generated identity
        "clOrdId",
        "secondaryClOrdId",
        "orderRequestId",
        "objectId",
        "objectRevision",
        "businessObjectRevision",
        # Persistence and audit, owned by the service
        "persistence",
        "lastUpdateTime",
        "signature",
        # System-calculated. The client's own cost columns are cross-check
        # inputs to validation only - never a destination.
        "costs",
        "validation",
    }
)


class DenyListViolation(AssertionError):
    """Raised when a mapped payload touches a system-owned field."""


def assert_clean(payload: dict[str, Any]) -> None:
    """Fail loudly if the mapper populated anything it must not.

    Called on every payload before it leaves the mapper, and asserted again
    in tests. A violation is a bug in the mapper, never something to work
    around at the call site.
    """
    violations = sorted(DENIED_FIELDS & payload.keys())
    if violations:
        raise DenyListViolation(
            "mapper populated system-owned field(s): " + ", ".join(violations)
        )
