One directory per fixture:

    0001-sunrise-sell-all-with-figure/
      source.eml              redacted original, NOT pasted text
      expected.capture.json   the label
      labels.yaml             phenomena tags
      notes.md                why this fixture exists, what it catches

Splits live in `labels.yaml` as `split: dev | holdout`.

Never commit unredacted email. See docs/corpus-spec.md section 3.
