# Spec: Extraction

## Purpose
Sanitized email content to a `CaptureModel`. One LLM call, no tools.

## Requirements

- **EX-1** Extraction has **no tool access**. It is a pure function from
  content to structure. Enrichment happens around it, in orchestration code.
- **EX-2** Structured output only, schema-constrained. On parse failure the
  message goes to the reviewer — never retry-and-hope, never fall back to
  free-text parsing.
- **EX-3** One model call per stage. No agentic self-iteration in the runtime
  path.
- **EX-4** Client email is untrusted input. It sits in a delimited region and
  the system prompt states that region is data, never instructions.
- **EX-5** Secrets, exchanged tokens and client holdings never enter a prompt.
- **EX-6** Absent values return null. The model never guesses. Hallucinated
  fields are counted separately in the evals and gated at zero.
- **EX-7** Every call records prompt version, prompt hash, model ID and the
  raw response for audit.

## Open
Live-region detection for quoted threads may warrant its own stage.
