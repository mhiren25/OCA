# First tasks — the runbook

Setup, the command reference, importing the six drafted proposals, and the
loop for running one.

---

## 1 · Install

```bash
cd trade-capture-agent
cp pip.conf.template pip.conf && $EDITOR pip.conf     # your Nexus URL
./init.sh
source .venv/bin/activate

ln -sf ../../scripts/hooks/pre-commit .git/hooks/pre-commit
$EDITOR CODEOWNERS                                    # replace @REPLACE-ME
```

Set `TC_AGENT=1` in the environment the coding agent runs in — that is how
the hook tells agent commits from yours.

Confirm the two test states:

```bash
pytest -q                  # BASELINE — green. Superpowers refuses to start otherwise
pytest -m acceptance -q    # TARGET — red. These are the criteria, not yet met
```

Both are correct. Acceptance tests are pre-written criteria, CODEOWNERS-
protected so the agent cannot edit them, and excluded from the default run
so the baseline Superpowers checks is clean.

### The two AI tools

```bash
npm install -g --registry "$NPM_REGISTRY" @fission-ai/openspec
openspec init
openspec config profile          # choose EXPANDED — /opsx:new and /opsx:ff live there
openspec update                  # installs the slash commands into Copilot

copilot plugin marketplace add obra/superpowers-marketplace
copilot plugin install superpowers@superpowers-marketplace
copilot plugin list              # confirm
```

`openspec init` creates `openspec/`. **This repo deliberately ships no
`openspec/` directory** — letting the tool own its own layout avoids a
structure that fights it.

---

## 2 · Command reference

### OpenSpec — CLI

| Command | Does |
|---|---|
| `openspec init` | Create `openspec/`, install slash commands |
| `openspec update` | Refresh agent instructions and slash commands |
| `openspec config profile` | Switch default ⇄ expanded |
| `openspec list` | List changes |
| `openspec status --change <name> --json` | Artifact and task state, scriptable |
| `openspec config set telemetry.enabled false` | If your org requires it |

### OpenSpec — slash commands, in Copilot

**Default profile:**

| Command | Does | Produces |
|---|---|---|
| `/opsx:explore` | Think through a problem | nothing — a thinking partner |
| `/opsx:propose` | Create a change **and all artifacts** at once | proposal.md, specs/, design.md, tasks.md |
| `/opsx:apply` | Implement, working the `tasks.md` checkboxes | code; updates artifacts as it goes |
| `/opsx:sync` | Push a change's delta specs into `openspec/specs/` | — |
| `/opsx:archive` | Move the change to `changes/archive/` | prompts to sync first |

**Expanded profile:**

| Command | Does |
|---|---|
| `/opsx:new <name>` | Scaffold a change: directory + `.openspec.yaml`, **no artifacts** |
| `/opsx:continue` | Create the next ready artifact, one at a time |
| `/opsx:ff` | Fast-forward: create all remaining artifacts at once |
| `/opsx:verify` | Check the implementation against the change's artifacts |
| `/opsx:bulk-archive` | Archive several completed changes |
| `/opsx:onboard` | Guided walkthrough |

Every command works on an existing partially-written change **except**
`/opsx:propose` and `/opsx:new`, which only create fresh ones.

### Superpowers — no commands, but name the skill

Skills activate on intent; there is no `/superpowers:*`. But naming the skill
in your instruction is the reliable way to get the pipeline you want:

| Skill | What it gives you |
|---|---|
| `brainstorming` | Questions before code |
| `writing-plans` | `docs/superpowers/plans/<date>-<name>.md` — tasks with files, interfaces, TDD micro-steps |
| `using-git-worktrees` | `.worktrees/<branch>` with deps installed |
| `subagent-driven-development` | Task-at-a-time pipeline: implementer → reviewer → fix, then a final whole-branch review |
| `test-driven-development` | Red before green, enforced |
| `systematic-debugging`, `verification-before-completion` | Ambient |
| `finishing-a-development-branch` | Merge/PR and cleanup |

`executing-plans` is the **fallback** for environments without subagents —
not the parallel option. See `docs/workflow.md` for the full mechanics and
the two build lanes.

---

## 3 · How OpenSpec tracks a change — and what it doesn't

```
openspec/
├── config.yaml
├── specs/                              main specs, synced from changes
└── changes/
    ├── <change-name>/
    │   ├── .openspec.yaml              schema binding + created date
    │   ├── proposal.md                 rationale and scope
    │   ├── specs/                      delta to the main specs
    │   ├── design.md                   technical approach
    │   ├── tasks.md                    checklist — [x] marks progress
    │   └── approval.yaml               ← OURS. Not an OpenSpec file
    └── archive/YYYY-MM-DD-<name>/
```

State comes from three things: which artifacts exist, the `[x]` checkboxes in
`tasks.md`, and whether the change sits in `changes/` or `changes/archive/`.
Artifacts have a dependency order — **proposal → specs → design → tasks**.

> **OpenSpec has no approval concept.** It tracks *progress*, not
> *permission*. "Three of eight tasks ticked" says nothing about whether a
> human agreed the work should happen, and for a system that writes into a
> trading platform that distinction matters. `approval.yaml` is ours and
> covers only that, so the two never contend over the same field. Template in
> `docs/proposals/_approval-template.yaml`.

A git hook cannot stop `/opsx:apply` from running. What it can do is stop an
agent **forging** the approval that authorises it, and stop it editing the
things that measure its work. The gate itself is procedural: you don't run
`/opsx:apply` until `approval.yaml` exists.

---

## 4 · Import the six drafted proposals

`docs/proposals/` holds six drafts. They are input material, not OpenSpec
changes — a directory without `.openspec.yaml` isn't a change OpenSpec can
see, so `/opsx:new` comes first.

Per proposal, in Copilot:

```
/opsx:new 001-capture-model-types
```

Then drop the draft in and let OpenSpec build the rest:

```bash
cp docs/proposals/001-capture-model-types.md \
   openspec/changes/001-capture-model-types/proposal.md
```

```
/opsx:ff
```

`/opsx:ff` reads `proposal.md` and generates `specs/`, `design.md` and
`tasks.md` in dependency order. Use `/opsx:continue` instead to approve each
artifact as it appears.

**Don't use `/opsx:propose` for these** — it cannot operate on an existing
change, so you'd get a duplicate and lose the draft.

### Seed the main specs

```bash
cp docs/specs-draft/capture-model.md openspec/specs/capture-model.md   # etc.
```

Five capability specs, written as numbered requirements (`MP-3`, `EX-5`) so
proposals and tests can cite them. OpenSpec's own style leans toward
requirements with concrete scenarios — reformat if `/opsx:` commands seem
unhappy with the shape. `docs/specs-draft/_project.md` is context for
`openspec/project.md` if init creates one.

---

## 5 · Order — the extraction path

Your goal is extraction accuracy on the 50 emails. Note which side of the
pipeline each proposal sits on:

```
ingest → sanitize → EXTRACT → enrich → map → draft
└──────── accuracy work ────────┘   └── not needed yet ──┘
```

The mapping-side proposals contribute **nothing** to measuring extraction
accuracy.

| # | Change | Why now |
|---|---|---|
| 1 | **001 capture-model-types** | Everything depends on it |
| 2 | **002 exec-instructions-budget** | **Calibration run.** Small, red test waiting. Judge the workflow here |
| 3 | 007 eml parsing | *Not drafted.* Gates everything — no fixture can be labelled until `.eml` parses |
| 4 | 008 sanitize / live-region | *Not drafted.* Hardest one: quoted-thread detection |
| 5 | 006 model-provider-cassettes + 009 live client | Model access |
| 6 | 010 extractor + prompt v1 | The first real prompt |
| 7 | 013 eval runner | Wire scoring to fixtures — **now you can measure** |
| — | *Label the ten hard fixtures* | Then start tuning |
| later | 003, 004, 005, 011, 012, 014 | Mapping side. Needed to emit real drafts, not to measure accuracy |

**Stop after 002 and judge.** Two changes is enough to tell whether the
workflow produces code you'd accept. Six diffs from a process you already
distrust is worse — you'll be tempted to accept them because you've sunk the
time.

---

## 6 · Running one

### Read it

```bash
$EDITOR openspec/changes/001-capture-model-types/proposal.md
$EDITOR openspec/changes/001-capture-model-types/tasks.md
```

Read `tasks.md` too — it's the agent's actual worklist, and a bad breakdown
is far cheaper to fix now than to review later as a sprawling diff.

I drafted these; you own them. Change anything you disagree with **before**
approving.

### Approve

```bash
cp docs/proposals/_approval-template.yaml \
   openspec/changes/001-capture-model-types/approval.yaml
$EDITOR openspec/changes/001-capture-model-types/approval.yaml
git add -A && git commit -m "approve 001-capture-model-types"
```

A human act, recorded in git. The hook blocks an agent from creating this.

### Implement — pick a lane

**Lane A · small, mechanical.** OpenSpec drives from `tasks.md`:

```
/opsx:apply

Before you start: read docs/workflow.md and .github/copilot-instructions.md.
Baseline is `pytest`; the target is `pytest -m acceptance`. Acceptance tests
are read-only — if one looks wrong, stop and tell me.
```

**Lane B · substantial.** Superpowers plans and runs the subagent pipeline,
with the change directory as its spec:

```
Use subagent-driven-development to implement
openspec/changes/001-capture-model-types/.

The change directory is the spec: read proposal.md, specs/ and design.md.
Copy the global constraints from .github/copilot-instructions.md into the
plan header. Baseline is `pytest`; the target is `pytest -m acceptance`,
and those tests are read-only. Use the most capable model for the final
review.
```

001 is lane B (three modules, the foundation everything types against).
002 is lane A (one module, ~40 lines, red test waiting).

Running both lanes on one change double-tracks progress — `tasks.md`
checkboxes and the Superpowers ledger will drift. Pick one and say which.

If it made a worktree:

```bash
scripts/seed-worktree.sh .worktrees/<branch>   # pip.conf + .env don't cross
```

Expect questions **before** any code — that's `brainstorming`, and the
answers are usually things the proposal should have said. Fold them back in.

### Verify

```bash
pytest -m acceptance -q          # the change's criteria — must now be green
pytest -q                        # baseline, incl. agent-written tests
ruff check . && mypy src/
git diff --stat                  # only what it should have touched?
```

```
/opsx:verify
```

That checks the implementation against the change's own artifacts — a
different question from whether the tests pass, and worth asking both. Then
check the diff against the proposal's **Out of scope** section; scope creep is
the most common agent failure and the easiest to catch here.

### Close it out

```
/opsx:sync        # delta specs → openspec/specs/
/opsx:archive     # → changes/archive/YYYY-MM-DD-001-capture-model-types/
```

`/opsx:archive` prompts to sync if you skip the first. Syncing *is* the
"update the spec when implementation proves it wrong" discipline — skipping it
is how specs rot.

```bash
git worktree remove ../tc-001    # if Superpowers made one
```

---

## 7 · What "good" looks like on the first run

- **Did it ask clarifying questions?** Silence means it's guessing.
- **Did tests fail before passing?** Tests written after the fact assert
  current behaviour and prove nothing.
- **Did it stay in scope?** Compare the diff to Out of scope.
- **Did it touch anything protected?** The hook should have stopped it — an
  attempt tells you the proposal was unclear about boundaries.
- **Is it code you'd have written?** If not: is the gap in the proposal, the
  spec, or the model? Usually the proposal.

That last question is the whole reason for doing 002 early.

### When it goes wrong

| Symptom | Cause | Fix |
|---|---|---|
| Wildly off-target code | Proposal too vague | Rewrite it, regenerate `tasks.md` with `/opsx:ff` |
| Touched 30 files | Bad task breakdown | Fix `tasks.md`, don't review the diff |
| Tried to edit an acceptance test | Real ambiguity, or laziness | Read the test yourself. Wrong → fix it in your own commit. Right → tighten the proposal |
| Asks about something the spec covers | Spec isn't discoverable | Reference it explicitly in the proposal |
| Right code, wrong style | Conventions unstated | Add to `.github/copilot-instructions.md` |

A failing test is **never** fixed by editing the expectation. Either the code
is wrong, the label is wrong (its own PR, with reasoning), or the spec is
wrong (a new change).

---

## 8 · Writing the rest yourself

007–014 aren't drafted, and you shouldn't wait on me. For a *new* change,
`/opsx:propose` is the right command — it creates the change and all four
artifacts in one step:

```
/opsx:propose Parse .eml into a CaptureEnvelope. Original MIME, not pasted
text: attachments, encodings, inline images and HTML table structure all
matter. See openspec/specs/capture-model.md and docs/corpus-spec.html §2.
```

Then edit what comes back before writing `approval.yaml`. Drafting is cheap;
the judgement in **Out of scope** and **Acceptance** has to be yours, and
that's true whether the first draft comes from me or the agent.

Remaining, in dependency order: 007 `eml.py` · 008 `sanitize/` ·
009 `openai_compatible.py` · 010 `extractor.py` + prompt v1 · 011 `mapper.py` ·
012 `clients/` · 013 `evals/runner.py` · 014 `api/app.py`.

`scripts/redact.py` and `scripts/label.py` are one-off tooling, not product —
write them by hand or with ad-hoc agent help. Routing them through the change
workflow is ceremony without benefit.

### Handy aliases

```bash
alias tc-changes='openspec list'
alias tc-state='openspec status --change'         # tc-state 001-capture-model-types --json
alias tc-approved='ls openspec/changes/*/approval.yaml 2>/dev/null'
alias tc-base='pytest -q'                      # baseline: must be green
alias tc-target='pytest -m acceptance -q'      # the change's criteria
alias tc-plans='ls docs/superpowers/plans/'
alias tc-ledger='cat .superpowers/sdd/progress.md'
alias tc-check='pytest -q && ruff check . && mypy src/'
alias tc-eval='python -m evals.runner --dev'
```

---

## 9 · What stays hand-written

`src/trade_capture/mapping/denylist.py` and `evals/scoring.py` are
implemented, not stubbed, and CODEOWNERS-protected alongside
`tests/acceptance/`, `corpus/` and every `approval.yaml`.

They are the referee. `denylist.py` is what makes "the agent cannot submit an
order" true; `scoring.py` decides whether a fabrication counts as a failure;
the acceptance tests and fixtures are the expectations; `approval.yaml` is
permission to act. An agent that writes all of those is grading its own work
at four levels, and the guardrails end up worth exactly as much as the agent
that authored them.

Everything else in `src/` is the agent's to write.
