"""Company OpenAI-compatible endpoint. Swaps for the internal gateway via TC_LLM_PROVIDER.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
