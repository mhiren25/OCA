<!-- draft proposal · import with /opsx:new 006-model-provider-cassettes then /opsx:ff
     spec: extraction -->

# 006-model-provider-cassettes

## Why

Today the extraction model is the company OpenAI-compatible endpoint; in
production it becomes the internal LLM gateway. That swap should be a config
change, which is the only reason a provider abstraction exists here — it stays
deliberately thin.

Separately: evals must hit the live model, because a fake would measure
nothing. But live calls in every unit test make the suite slow,
non-deterministic and expensive, and a suite like that stops being run.
Record/replay gives both.

## What changes

`extraction/providers/base.py`
- `Exchange` frozen dataclass: prompt_version, prompt_hash, model, request,
  response, latency_ms
- `Provider` ABC with
  `async extract(*, system, content, schema, prompt_version) -> Exchange`

`extraction/providers/cassette.py`
- `cassette_key(prompt_hash, model, content) -> str`
- `RecordingProvider(inner, cassette_dir)` — delegates, writes the exchange
- `ReplayProvider(cassette_dir, prompt_hash, model)` — serves recordings and
  **raises `FileNotFoundError` on a miss**

The miss behaviour matters: falling through to the network would mean CI
silently making live calls. A missing cassette must be a visible failure.

Keying on prompt_hash means changing the prompt invalidates recordings rather
than replaying stale answers against a prompt that no longer exists.

## Out of scope

`openai_compatible.py` — the real HTTP client is its own proposal. This
delivers the interface and the record/replay pair; a fake implementing
`Provider` is enough to test them.

## Acceptance

- `RecordingProvider` writes one JSON file per exchange, named by
  `cassette_key`, and returns the inner provider's Exchange unchanged.
- `ReplayProvider` returns a recorded exchange for a matching key.
- `ReplayProvider` raises FileNotFoundError on a miss, with a message naming
  the key and suggesting `TC_LLM_RECORD=1`. It must **never** attempt network
  access — assert this with `respx` or an equivalent.
- A different prompt_hash for the same content is a cache miss.
- Recorded JSON is `sort_keys=True` and indented, so cassette diffs are
  readable in review.
- Round trip: record then replay yields an equivalent Exchange.

## Risks

The provider interface growing to accommodate provider-specific features. If
the gateway needs something the endpoint does not, that is a conversation, not
a new optional kwarg. Also: **cassettes must never contain secrets or client
holdings** — they are committed. Assert on recorded content if there is any
doubt.
