#!/usr/bin/env bash
#
# Trade Capture Agent - development environment bootstrap.
#
# Idempotent: safe to re-run. Creates the virtualenv, installs dependencies
# from the configured index, and reports on the optional AI tooling.
#
# Usage:
#   ./init.sh                 full setup
#   ./init.sh --deps-only     venv + dependencies, skip tooling checks
#   ./init.sh --check         report state, change nothing
#
# Configuration is read from .env if present, then the environment.
# See .env.example and pip.conf.template for the Nexus placeholders.

set -euo pipefail

readonly REQUIRED_PYTHON_MINOR=11
readonly VENV_DIR=".venv"
readonly ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DEPS_ONLY=0
CHECK_ONLY=0

# ---------------------------------------------------------------- output ----

if [[ -t 1 ]]; then
  C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
  C_RED=$'\033[31m'; C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'
else
  C_RESET=""; C_BOLD=""; C_DIM=""; C_RED=""; C_GREEN=""; C_YELLOW=""
fi

step() { printf '\n%s==>%s %s%s%s\n' "$C_BOLD" "$C_RESET" "$C_BOLD" "$1" "$C_RESET"; }
ok()   { printf '    %s+%s %s\n' "$C_GREEN" "$C_RESET" "$1"; }
warn() { printf '    %s!%s %s\n' "$C_YELLOW" "$C_RESET" "$1"; }
err()  { printf '    %sx%s %s\n' "$C_RED" "$C_RESET" "$1" >&2; }
note() { printf '      %s%s%s\n' "$C_DIM" "$1" "$C_RESET"; }

die() { err "$1"; exit 1; }

# ------------------------------------------------------------------ args ----

for arg in "$@"; do
  case "$arg" in
    --deps-only) DEPS_ONLY=1 ;;
    --check)     CHECK_ONLY=1 ;;
    -h|--help)   sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)           die "unknown option: $arg (try --help)" ;;
  esac
done

cd "$ROOT"

# --------------------------------------------------------------- .env -------

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

PIP_INDEX_URL="${PIP_INDEX_URL:-}"
NPM_REGISTRY="${NPM_REGISTRY:-}"

# ------------------------------------------------------------- python -------

step "Python"

PYTHON_BIN=""
for candidate in python3.13 python3.12 python3.11 python3 python; do
  if command -v "$candidate" >/dev/null 2>&1; then
    minor="$("$candidate" -c 'import sys; print(sys.version_info.minor)' 2>/dev/null || echo 0)"
    major="$("$candidate" -c 'import sys; print(sys.version_info.major)' 2>/dev/null || echo 0)"
    if [[ "$major" -eq 3 && "$minor" -ge "$REQUIRED_PYTHON_MINOR" ]]; then
      PYTHON_BIN="$candidate"; break
    fi
  fi
done

[[ -n "$PYTHON_BIN" ]] || die "Python 3.${REQUIRED_PYTHON_MINOR}+ not found on PATH."
ok "$("$PYTHON_BIN" --version) at $(command -v "$PYTHON_BIN")"

# ---------------------------------------------------------------- venv ------

step "Virtual environment"

if [[ "$CHECK_ONLY" -eq 1 ]]; then
  [[ -d "$VENV_DIR" ]] && ok "$VENV_DIR exists" || warn "$VENV_DIR missing"
else
  if [[ -d "$VENV_DIR" ]]; then
    ok "$VENV_DIR already present, reusing"
  else
    "$PYTHON_BIN" -m venv "$VENV_DIR"
    ok "created $VENV_DIR"
  fi
  # shellcheck disable=SC1091
  source "$VENV_DIR/bin/activate"
  python -m pip install --quiet --upgrade pip setuptools wheel
  ok "pip $(pip --version | awk '{print $2}')"
fi

# -------------------------------------------------------- package index -----

step "Package index"

PIP_ARGS=()
if [[ -f pip.conf ]]; then
  export PIP_CONFIG_FILE="$ROOT/pip.conf"
  ok "using pip.conf"
  note "$(grep -E '^\s*(index-url|trusted-host)' pip.conf | tr -d ' ' | paste -sd' ' -)"
elif [[ -n "$PIP_INDEX_URL" ]]; then
  PIP_ARGS+=(--index-url "$PIP_INDEX_URL")
  host="$(printf '%s' "$PIP_INDEX_URL" | sed -E 's#^[a-z]+://([^/@]*@)?([^/:]+).*#\2#')"
  PIP_ARGS+=(--trusted-host "$host")
  ok "using PIP_INDEX_URL ($host)"
else
  warn "no internal index configured - falling back to the pip default"
  note "cp pip.conf.template pip.conf and set your Nexus URL,"
  note "or export PIP_INDEX_URL. See README section 'Package index'."
fi

# -------------------------------------------------------- dependencies ------

step "Dependencies"

if [[ "$CHECK_ONLY" -eq 1 ]]; then
  note "skipped (--check)"
else
  pip install --quiet "${PIP_ARGS[@]+"${PIP_ARGS[@]}"}" -r requirements.txt
  ok "runtime dependencies installed"
  pip install --quiet "${PIP_ARGS[@]+"${PIP_ARGS[@]}"}" -r requirements-dev.txt
  ok "development dependencies installed"
  pip install --quiet "${PIP_ARGS[@]+"${PIP_ARGS[@]}"}" -e . >/dev/null 2>&1 \
    && ok "trade_capture installed in editable mode" \
    || warn "editable install skipped"
fi

# ---------------------------------------------------------------- env -------

step "Local configuration"

if [[ "$CHECK_ONLY" -eq 0 && ! -f .env ]]; then
  cp .env.example .env
  ok "created .env from .env.example"
  warn "fill in TC_LLM_BASE_URL and TC_LLM_API_KEY before running evals"
else
  [[ -f .env ]] && ok ".env present" || warn ".env missing (copy from .env.example)"
fi

# ------------------------------------------------------------- openspec -----

if [[ "$DEPS_ONLY" -eq 0 ]]; then
  step "OpenSpec"

  if command -v openspec >/dev/null 2>&1; then
    ok "openspec $(openspec --version 2>/dev/null || echo 'present')"
    if [[ -d openspec ]]; then
      ok "openspec/ initialised - $(openspec list 2>/dev/null | wc -l | tr -d ' ') change(s)"
    else
      warn "openspec/ not initialised yet - run: openspec init"
      note "then import the drafts in docs/proposals/ (docs/first-tasks.md)"
    fi
  else
    warn "openspec not on PATH"
    if [[ -n "$NPM_REGISTRY" ]]; then
      note "npm install -g --registry $NPM_REGISTRY @fission-ai/openspec"
    else
      note "npm install -g @fission-ai/openspec   # set NPM_REGISTRY for Nexus"
    fi
    note "Then:  openspec init"
    note "       openspec config profile     # choose EXPANDED"
    note "       openspec update"
    note "See docs/first-tasks.md for the full import sequence."
  fi

  # ----------------------------------------------------------- copilot -----

  step "GitHub Copilot CLI"

  if command -v copilot >/dev/null 2>&1; then
    ok "copilot CLI present"
    if copilot plugin list 2>/dev/null | grep -qi superpowers; then
      ok "superpowers plugin installed"
    else
      warn "superpowers plugin not installed"
      note "copilot plugin marketplace add obra/superpowers-marketplace"
      note "copilot plugin install superpowers@superpowers-marketplace"
    fi
  else
    warn "copilot CLI not on PATH - see README section 'AI tooling'"
  fi

  # ------------------------------------------------------------ vscode -----

  step "VS Code"

  if command -v code >/dev/null 2>&1; then
    ok "code CLI present"
    note "Open the repo and accept the recommended extensions prompt,"
    note "or run: code --install-extension GitHub.copilot --install-extension GitHub.copilot-chat"
  else
    warn "code CLI not on PATH (Command Palette > 'Shell Command: Install code command')"
  fi
fi

# ---------------------------------------------------------------- done ------

step "Ready"
cat <<'EOF'
    source .venv/bin/activate

    pytest tests/                      unit + mapper tests (no model calls)
    python -m evals.runner --help      corpus eval runner (live model)
    python -m evals.runner --dev       run the dev split
    python -m evals.runner --holdout   the interim 10 - use sparingly

    docs/workflow.md                   how specs and coding tasks flow
    openspec/specs/                    the starter specifications
EOF
printf '\n'
