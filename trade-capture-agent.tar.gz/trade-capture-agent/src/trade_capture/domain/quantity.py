"""Quantity as a union: Absolute | EntirePosition | UnresolvedQuantity.

NOT IMPLEMENTED - see openspec/changes/001-capture-model-types/proposal.md
Spec: capture-model CM-2, CM-3
"""

from __future__ import annotations
