<!-- draft proposal · import with /opsx:new 003-deterministic-validators then /opsx:ff
     spec: mapping -->

# 003-deterministic-validators

## Why

Business rules belong in code, not in the prompt. A prompt is a suggestion; a
validator is a guarantee. These catch the specific failure modes our sample
emails invite, and none of them needs a model.

The order table in one sample carries `curr px` and `Cost` columns alongside
`QTY`, and they reconcile exactly:

    290   x   151.90 =     44,051
    3,900 x 4,172.00 = 16,270,800

That is a free arithmetic checksum on the extraction, and it catches precisely
what a misaligned plain-text table produces — column drift, dropped digits,
thousand-separator misreads.

## What changes

`validation/validators.py`, pure functions, no I/O:

- `cost_arithmetic_holds(qty, px, stated_cost) -> bool` — Decimal throughout,
  1% tolerance for rounding, True when stated_cost is zero (nothing to check)
- `isin_checksum_valid(isin) -> bool` — ISO 6166 mod-10, letters expanded to
  their two-digit values
- `currency_matches(stated, resolved) -> bool` — client-stated currency is a
  cross-check, never a source
- `venue_matches(stated, resolved) -> bool` — client-stated venue is honoured,
  but disagreement with the resolver is flagged
- `enum_closed(value, allowed) -> bool` — from `config/enums.yaml`
- `sentinel_guard(field, value, was_parsed) -> bool` — `price=0.0` means
  market-priced and `targetStrategy=UNSET` means no algo. Neither may be
  written to mean "we could not parse this"
- `date_within_window(trade_date, received_at, window_days) -> bool`
- `line_count_within(n, maximum) -> bool`

Every function returns a bool. **None of them raises and none corrects
anything** — a validator reports, the caller decides, and a failure becomes a
flag on the draft rather than a rejection.

## Out of scope

Wiring validators into the pipeline, and the flag representation on the draft.
This proposal delivers the checks; a later one applies them.

## Acceptance

`tests/acceptance/test_validators.py` passes. CODEOWNERS-protected — do not
edit. It asserts both real sample rows reconcile, that column drift (qty and
price read from adjacent columns) is caught, and that `CH0038863350` validates
while a corrupted check digit does not.

Also required:
- `sentinel_guard` rejects `price=0.0` when `was_parsed` is False, and permits
  it when True.
- Decimal arithmetic throughout — no float comparison anywhere in this module.
- Unit tests for each remaining function.

## Risks

Tolerance creep on `cost_arithmetic_holds`. 1% absorbs rounding in a displayed
price. Widening it to make a stubborn fixture pass converts a real check into
decoration — if a fixture fails this check, the extraction is probably wrong.
