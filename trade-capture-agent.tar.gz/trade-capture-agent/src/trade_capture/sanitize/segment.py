"""Segment rather than delete. Signatures often carry the account and authority - annotate, never strip.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
