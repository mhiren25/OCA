<!-- draft proposal · import with /opsx:new 002-exec-instructions-budget then /opsx:ff
     spec: mapping -->

# 002-exec-instructions-budget

## Why

`execInstructions` is where everything unmappable goes — a short-selling
instruction, an unrecognised algo, a sell-all note — and it holds 256
characters.

The Draft Order service **trims on overflow rather than rejecting**, which
makes the dangerous outcome the silent one. A blind cut at character 256 lands
wherever it lands:

    "Do not exceed 100k"   ->   "do not exceed 10"

The meaning inverts and nothing raises. So the service's trim must never fire:
the mapper emits a string already inside the limit, cut at instruction
boundaries.

## What changes

`mapping/exec_instructions.py`

- `MAX_LEN = 256`, `SEPARATOR = " | "`
- `Budget` dataclass: `text` (always <= MAX_LEN) and `omitted`
  (tuple of `Unmapped` that did not fit)
- `build(instructions: list[Unmapped]) -> Budget`

Fill order is `priority` ascending, ties broken by `provenance.start` so
output is deterministic for a given input:

| Priority | Content |
|---|---|
| 10 | Execution constraints — "no short selling", limits, restrictions |
| 20 | Unresolved quantity context |
| 30 | Unmapped strategy or handling, raw phrase verbatim |
| 50 | Everything else (default) |

An instruction that does not fit **whole** is omitted entirely and returned in
`omitted`. Never shortened, never partially included.

## Out of scope

Who sets `priority` — that is the extractor's job. Deciding which instructions
are unmappable — that is the mapper's. This function receives a list and fills
a field.

## Acceptance

`tests/acceptance/test_exec_instructions.py` passes. It is CODEOWNERS-
protected: **do not edit it.** If a test looks wrong, stop and say so.

Notably it asserts that when "do not exceed 100k" is dropped for space,
neither "do not exceed 10" nor "do not exceed" appears in the output — a
partial instruction that reads as a valid one is the failure this whole
proposal exists to prevent.

Also required:
- `assert len(text) <= MAX_LEN` inside `build`, so a bug here fails loudly
  rather than silently handing the service something to trim.
- Empty input returns empty text and no omissions.
- Output is deterministic across runs for the same input.

## Risks

Being clever about fitting more in — reordering by length, abbreviating,
dropping the separator. Don't. Predictable output that a trader can learn to
read beats a densely packed field. If overflow turns out to be common, that is
a conversation about the field, not a reason to compress.
