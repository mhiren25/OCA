from __future__ import annotations

import pytest


def pytest_collection_modifyitems(config, items):
    """Live-model tests are opt-in. CI runs replay only."""
    if config.getoption("-m"):
        return
    skip_live = pytest.mark.skip(reason="live model test - run explicitly with -m live")
    for item in items:
        if "live" in item.keywords:
            item.add_marker(skip_live)
