"""CaptureModel -> OrderRequest. Deterministic, unit-testable, no LLM. Calls denylist.assert_clean before returning.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
