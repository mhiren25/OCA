"""Deduplication keys and the externalOrderReference capture reference.

NOT IMPLEMENTED - see openspec/changes/004-capture-reference/proposal.md
Spec: mapping MP-5
"""

from __future__ import annotations
