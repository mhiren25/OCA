"""Record live model exchanges; replay them in tests.

NOT IMPLEMENTED - see openspec/changes/006-model-provider-cassettes/proposal.md
Spec: extraction EX-7
"""

from __future__ import annotations
