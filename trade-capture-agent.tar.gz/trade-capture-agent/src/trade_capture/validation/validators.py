"""Deterministic checks that run after the LLM, in code.

NOT IMPLEMENTED - see openspec/changes/003-deterministic-validators/proposal.md
Spec: mapping MP-2, corpus CO-4
"""

from __future__ import annotations
