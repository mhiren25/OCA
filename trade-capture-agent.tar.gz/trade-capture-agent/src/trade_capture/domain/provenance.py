"""Where a value came from: source part and character span.

NOT IMPLEMENTED - see openspec/changes/001-capture-model-types/proposal.md
Spec: capture-model CM-4
"""

from __future__ import annotations
