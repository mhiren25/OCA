"""Shared MCP transport - uniform auth, retries, observability. Pinned tool manifest: a server whose tool descriptions change is an injection vector.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
