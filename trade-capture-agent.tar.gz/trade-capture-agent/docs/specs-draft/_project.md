# Trade Capture Agent

Captures trade orders from client email and produces **draft orders** in the
Draft Order service. A human reviews every draft before submission.

## Boundary

Terminal state is a saved draft. The service performs no action visible to a
market, a counterparty, or the client. Amendment, cancellation, approval and
submission belong to the existing GUI.

## Phase 1

Email channel · Equity and fixed income · Accounts supplied as input ·
Instrument resolution via MCP · Sync HTTP · Draft only.

## Governing documents

- `docs/domain-model.md` — capture schema and the mapping to `OrderRequest`
- `docs/corpus-spec.md` — how the eval corpus is built, labelled and gated
- `docs/workflow.md` — how proposals become code

## Invariants

1. The agent cannot submit an order — it cannot write `lifecycleData.canSubmit`.
2. Extraction has no tools and cannot call anything.
3. No business rule lives in a prompt that could live in a validator.
4. No sentinel value ever means "we could not parse this".
5. Fabrication budget is zero.
