# Spec: Mapping

## Purpose
`CaptureModel` to `OrderRequest`. Deterministic, no LLM.

## Requirements

- **MP-1** No system-owned field is ever written. `denylist.assert_clean`
  runs on every payload. `lifecycleData.canSubmit` above all — this is the
  mechanical form of the draft-only invariant.
- **MP-2** A sentinel is never written to mean "unparsed". `price=0.0` means
  market-priced; `targetStrategy=UNSET` means no algo. An unknown limit price
  leaves the field unset and the draft incomplete.
- **MP-3** `execInstructions` is emitted already within 256 characters, cut at
  instruction boundaries. The service trims blindly, so its trim must never
  fire. An instruction that does not fit whole is omitted and flagged.
- **MP-4** `execInstrs` (enum list) and `execInstructions` (free text) are
  distinct fields. Both types are asserted before the call.
- **MP-5** `externalOrderReference` carries `TCA-<capture_id>-<line>`,
  at most 64 characters.
- **MP-6** `EntirePosition` leaves `orderQty` unset in Phase 1. Incomplete
  drafts are accepted and this is a supported outcome.
- **MP-7** Absent `timeInForce` defaults to `DAY`. `GTD` without a stated
  expiry leaves `expireDate` unresolved — never fabricated.
- **MP-8** The agent's own `partyId` is written with
  `partyRole=ENTERING_SYSTEM`, so every agent draft is attributable in the
  system of record.
- **MP-9** Multi-line emails produce n drafts sharing a `capture_batch_id`.
  All lines are created; unresolvable ones are flagged. Never all-or-nothing,
  never silently dropped.
