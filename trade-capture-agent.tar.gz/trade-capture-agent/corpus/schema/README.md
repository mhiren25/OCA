`capture.v<n>.schema.json` — JSON Schema for `expected.capture.json`.

Generate from the Pydantic models; commit the generated file so fixtures can
be validated without importing the package, and so a schema change is visible
in review.

CODEOWNERS-protected: a schema change invalidates labels.
