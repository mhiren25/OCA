"""Pure function: sanitized content -> CaptureModel. Has NO tools and cannot call anything. An LLM that cannot reach the order service cannot create a weird order.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
