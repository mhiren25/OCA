"""Parse .eml into a CaptureEnvelope. Original MIME, not pasted text - attachments, encodings, inline images and HTML table structure are all part of what gets tested.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
