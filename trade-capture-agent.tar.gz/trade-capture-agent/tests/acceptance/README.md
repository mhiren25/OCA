Acceptance tests for change proposals. Written by a human BEFORE the work,
CODEOWNERS-protected, and never edited by an agent.

These are the red tests a proposal must turn green. An agent that can edit
its own acceptance criteria has none — same reason `corpus/fixtures/` is
protected.

Agent-written tests go in `tests/unit/` and `tests/mapper/`. Those are
expected to grow with every change.
