"""Accounts are input in Phase 1. This becomes an MCP resolver when clients start giving them in the body.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
