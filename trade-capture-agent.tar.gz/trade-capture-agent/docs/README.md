| | |
|---|---|
| `domain-model.html` | Capture schema, field-by-field mapping to `OrderRequest`, validators, the deny-list. Everything else derives from this |
| `corpus-spec.html` | Fixture format, redaction, labelling protocol, tri-state scoring, coverage matrix, CI gates |
| `workflow.md` | How a change becomes code: OpenSpec owns intent, Superpowers owns execution |
| `first-tasks.md` | Setup, command reference, importing the drafts, the loop |
| `proposals/` | Six drafted change proposals. **Input material** — import with `/opsx:new` then `/opsx:ff` |
| `specs-draft/` | Five capability specs to seed `openspec/specs/` after `openspec init` |

`openspec/` is not in this repo. `openspec init` creates it — letting the
tool own its own layout avoids shipping a structure that fights it.

Both HTML documents are also published as shareable pages.
