"""Typed client for the Draft Order service. Not MCP: a financially consequential write is not something a model should discover.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
