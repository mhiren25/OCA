#!/usr/bin/env bash
# Seed a fresh Superpowers worktree with the machine-local config that git
# does not carry across.
#
#   scripts/seed-worktree.sh [worktree-path]
#
# Why this exists: Superpowers auto-runs `pip install -r requirements.txt`
# when it creates a worktree. But pip.conf and .env are gitignored, so a new
# worktree has neither — and the install silently reaches for public PyPI,
# which fails behind Nexus. Copy them across first.
#
# Better still, export PIP_INDEX_URL and NPM_REGISTRY in your shell profile:
# environment variables follow you into every worktree, files do not.

set -euo pipefail

MAIN="$(git rev-parse --show-toplevel)"
WT="${1:-$PWD}"

[[ -d "$WT" ]] || { echo "no such directory: $WT" >&2; exit 1; }
[[ "$WT" != "$MAIN" ]] || { echo "that is the main worktree, nothing to seed" >&2; exit 0; }

for f in pip.conf .env; do
  if [[ -f "$MAIN/$f" && ! -f "$WT/$f" ]]; then
    cp "$MAIN/$f" "$WT/$f"
    echo "seeded $f"
  fi
done

echo
echo "now, inside the worktree:  ./init.sh --deps-only"
