# Copilot instructions - Trade Capture Agent

Read `docs/workflow.md` before starting work, and the specification in
`openspec/specs/` for whatever you are changing.

## Hard rules

1. **No code without approval.** The change directory must contain an
   `approval.yaml` naming a human. OpenSpec's own artifacts track progress,
   not permission — the absence of `approval.yaml` means nobody has agreed
   this should be built. Stop and say so.
2. **Never edit `corpus/`, `evals/scoring.py`, `tests/acceptance/` or any
   `approval.yaml`.** A failing test is never fixed by editing the
   expectation. If one looks wrong, say so and stop.
3. **Never edit `openspec/specs/` directly.** Main specs change only via
   `/opsx:sync` from an approved change. Delta specs inside your own change
   directory are yours to update as implementation reveals issues.
4. **Never add a field to `mapping/denylist.py`'s allowed set**, and never
   write `lifecycleData`, `canSubmit`, `clOrdId` or any other system-owned
   field. The agent produces drafts only.
5. **Never put a business rule in a prompt** that belongs in a validator.
   Prompts are suggestions; validators are guarantees.
6. **Never write a sentinel to mean "unparsed".** `price=0.0` means market
   priced. `targetStrategy=UNSET` means no algo. An unknown value leaves the
   field unset and the draft incomplete - that is a supported outcome.
7. **New dependencies need human approval.** Say what you need and why.
8. Tests fail before they pass. A test written after the fact that asserts
   current behaviour proves nothing.

## Running a change

The OpenSpec change directory is the **spec document**. A Superpowers plan
implements it — link the plan header back to the change and copy the global
constraints below into it verbatim.

- **Baseline is `pytest`** (acceptance tests excluded by marker) and must be
  green before you start. **The target is `pytest -m acceptance`** and must
  be green before you are done. Acceptance tests are read-only.
- **`tasks.md` and a Superpowers plan both want to drive.** Pick one per
  change and say which. Do not tick `tasks.md` boxes and keep a separate
  progress ledger for the same work.
- **Specify the model on every subagent dispatch.** Omitting it inherits the
  session default. Mechanical work: cheapest. Multi-file integration:
  standard. Architecture and **every final review**: most capable.
- **Dispatch implementers one at a time.** Isolation comes from each subagent
  seeing only its own task, not from concurrency.
- **A fresh worktree has no `pip.conf` or `.env`** — they are gitignored. Run
  `scripts/seed-worktree.sh` before installing dependencies, or the install
  reaches for public PyPI and fails behind Nexus.
- When a task reviewer reports **"Cannot verify from diff"**, resolve it with
  cross-task context. Never record it as a pass.

## Conventions

- Python 3.11+, `from __future__ import annotations`, full type hints.
- Pydantic v2 for every boundary model.
- The tri-state (`Mapped` / `Unmapped` / `Unresolved`) is the core
  abstraction - never collapse it to `Optional`.
- `Quantity` is a union, never a float.
- Extraction has no tools. Enrichment calls are issued by orchestration code.
- Client holdings, tokens and credentials never enter a prompt.
