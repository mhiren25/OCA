"""Tri-state field wrapper: Mapped | Unmapped | Unresolved.

NOT IMPLEMENTED - see openspec/changes/001-capture-model-types/proposal.md
Spec: capture-model CM-1, CM-6
"""

from __future__ import annotations
