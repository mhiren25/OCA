"""Ordered resolver chain with declared dependencies.

NOT IMPLEMENTED - see openspec/changes/005-enrichment-registry/proposal.md
Spec: enrichment EN-1, EN-7
"""

from __future__ import annotations
