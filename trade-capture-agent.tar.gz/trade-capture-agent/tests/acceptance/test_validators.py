"""Arithmetic cross-check, verified against the real sample emails."""

from __future__ import annotations

from decimal import Decimal

import pytest

from trade_capture.validation.validators import cost_arithmetic_holds, isin_checksum_valid


@pytest.mark.parametrize(
    ("qty", "px", "cost"),
    [(290, "151.90", 44051), (3900, "4172.00", 16270800)],
)
def test_sample_emails_reconcile(qty: int, px: str, cost: int) -> None:
    assert cost_arithmetic_holds(Decimal(qty), Decimal(px), Decimal(cost))


def test_column_drift_is_caught() -> None:
    # qty and price read out of adjacent columns
    assert not cost_arithmetic_holds(Decimal(3900), Decimal("151.90"), Decimal(16270800))


def test_isin_checksum() -> None:
    assert isin_checksum_valid("CH0038863350")
    assert not isin_checksum_valid("CH0038863351")
