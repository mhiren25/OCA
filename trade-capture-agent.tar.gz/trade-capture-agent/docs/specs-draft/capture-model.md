# Spec: Capture model

## Purpose
The schema the LLM produces. Owned by us, distinct from the fixed
`OrderRequest` payload. The LLM extracts into this; code maps out of it.

## Requirements

- **CM-1** Every extracted field is `Mapped` | `Unmapped` | `Unresolved`.
  Collapsing to `Optional` is a defect.
- **CM-2** `Quantity` is a union — `Absolute`, `EntirePosition`,
  `UnresolvedQuantity` — never a float.
- **CM-3** `EntirePosition` carries `client_asserted` and `resolved_position`
  independently. When both are present and disagree, both survive to the
  reviewer; the agent does not reconcile them.
- **CM-4** Every leaf value carries `Provenance` naming the source part and
  span. A span that does not contain the value it claims is a defect even
  when the value is correct.
- **CM-5** One email yields `0..n` `OrderIntent` lines. Zero is valid.
- **CM-6** `UnmappedInstruction` preserves the client's raw text verbatim,
  with a reason and a priority.

## Non-goals
Payload shape. That is `mapping`.
