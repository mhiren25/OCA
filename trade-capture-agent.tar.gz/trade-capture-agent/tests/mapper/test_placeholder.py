"""Mapper tests: CaptureModel in, OrderRequest out.

Fast, deterministic, no LLM and no email parsing - which is exactly why the
churny mapping logic belongs on this side of the line rather than in the
corpus.
"""

from __future__ import annotations


def test_suite_is_wired() -> None:
    assert True
