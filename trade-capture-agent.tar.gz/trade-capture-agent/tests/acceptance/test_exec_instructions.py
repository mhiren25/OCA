"""The service trims blindly at 256. Ours must never let it."""

from __future__ import annotations

from trade_capture.domain.provenance import Provenance, SourcePart
from trade_capture.domain.states import Unmapped, UnmappedReason
from trade_capture.mapping.exec_instructions import MAX_LEN, build


def _u(text: str, priority: int, start: int = 0) -> Unmapped:
    return Unmapped(
        raw_text=text,
        provenance=Provenance(part=SourcePart.BODY_TEXT, start=start, end=start + len(text)),
        reason=UnmappedReason.NO_TARGET_FIELD,
        priority=priority,
    )


def test_priority_order_is_respected() -> None:
    result = build([_u("later", 50), _u("no short selling for sell order", 10, 10)])
    assert result.text.startswith("no short selling")


def test_never_exceeds_the_limit() -> None:
    result = build([_u("x" * 200, 10), _u("y" * 200, 20, 300)])
    assert len(result.text) <= MAX_LEN


def test_overflow_omits_whole_instructions_never_truncates() -> None:
    keep = _u("a" * 200, 10)
    drop = _u("do not exceed 100k", 20, 300)
    result = build([keep, drop])

    assert drop in result.omitted
    # The dangerous failure: a partial instruction that reads as a valid one.
    assert "do not exceed 10" not in result.text
    assert "do not exceed" not in result.text
