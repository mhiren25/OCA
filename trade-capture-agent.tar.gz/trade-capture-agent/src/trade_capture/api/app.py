"""Sync HTTP entrypoint. Single responsibility: produce draft orders. Terminal state is a draft.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
