# Spec: Enrichment

## Purpose
Resolve what the client said into canonical identifiers, via MCP resolvers.

## Requirements

- **EN-1** Resolvers form an ordered chain with declared dependencies.
  Position depends on account and instrument.
- **EN-2** A resolver never raises on a miss. Unresolvable is a normal
  outcome that reaches the reviewer.
- **EN-3** Ambiguity returns **candidates with scores**, never one silently
  chosen answer.
- **EN-4** A client-stated venue is **honoured** and takes precedence over the
  resolver's default listing. Disagreement is flagged, not silently overridden.
- **EN-5** A client-stated currency is a **cross-check**, not a source.
  Mismatch against the resolver is flagged.
- **EN-6** MCP tool manifests are pinned and diffed on deploy. A server whose
  tool descriptions change is an injection vector.
- **EN-7** Resolvers are called by orchestration code on resolved keys. The
  model does not choose whether or when to call one.

## Phase 2
Position resolver. `resolved_position` is a suggestion with a mandatory
`as_of`, never a silent fill.
