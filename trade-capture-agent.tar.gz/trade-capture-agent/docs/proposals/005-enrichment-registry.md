<!-- draft proposal · import with /opsx:new 005-enrichment-registry then /opsx:ff
     spec: enrichment -->

# 005-enrichment-registry

## Why

Three resolvers — client/account, instrument, position — and the third depends
on the first two, since a holding is keyed by account *and* instrument. Hand
sequencing those calls means rewiring the pipeline every time one is added.
Declared dependencies mean adding a resolver is registering it.

## What changes

`enrichment/registry.py`

- `Resolver` ABC with class vars `name`, `depends_on: tuple[str, ...]`,
  `reasoning_required: bool`, and `async resolve(intent, context)`
- `Registry.register(resolver)` and `Registry.ordered() -> list[Resolver]`,
  topologically sorted
- `ValueError` on a cycle or an unregistered dependency

`reasoning_required` documents a distinction worth preserving as resolvers
accumulate: **MCP as transport is not the same as the model deciding to call
it.** Instrument lookup benefits from model judgement — a fuzzy name yields
candidates. A position read does not: it is a keyed lookup with one right
answer. Both go over MCP for uniform auth and observability, but both are
*called by orchestration code* on resolved keys.

## Out of scope

The resolvers themselves, MCP transport, and returning candidate sets. This is
the chain, not what hangs off it.

## Acceptance

- Registering position (depends on instrument and account), instrument and
  account in any order yields an ordering where position comes after both.
- A cycle raises ValueError naming a resolver in the cycle.
- Depending on an unregistered resolver raises ValueError naming both.
- Ordering is deterministic for a given registration set.
- A resolver that returns nothing does not raise. **An unresolvable value is a
  normal outcome that reaches the reviewer**, never an error condition.

## Risks

Growing this into a general workflow engine. It is a topological sort over a
handful of nodes. If it exceeds ~80 lines, it is doing too much.
