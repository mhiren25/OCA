"""Model provider interface. Thin: it exists so the gateway swap is config.

NOT IMPLEMENTED - see openspec/changes/006-model-provider-cassettes/proposal.md
Spec: extraction EX-2, EX-5
"""

from __future__ import annotations
