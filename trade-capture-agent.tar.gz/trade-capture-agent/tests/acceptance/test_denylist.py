"""The draft-only invariant, as a test.

If this ever fails, the agent has gained the ability to submit an order.
"""

from __future__ import annotations

import pytest

from trade_capture.mapping.denylist import DENIED_FIELDS, DenyListViolation, assert_clean


def test_clean_payload_passes() -> None:
    assert_clean({"side": "SELL", "currency": "JPY", "orderQtyData": {"orderQty": 3900}})


def test_can_submit_is_rejected() -> None:
    with pytest.raises(DenyListViolation, match="lifecycleData"):
        assert_clean({"side": "SELL", "lifecycleData": {"canSubmit": True}})


@pytest.mark.parametrize("field", sorted(DENIED_FIELDS))
def test_every_denied_field_is_rejected(field: str) -> None:
    with pytest.raises(DenyListViolation):
        assert_clean({field: "anything"})
