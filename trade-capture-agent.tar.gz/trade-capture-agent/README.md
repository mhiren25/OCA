# Trade Capture Agent

Captures trade orders from client email and produces **draft orders** in the
Draft Order service. A human reviews every draft before it is submitted.

```
  .eml  ──▶  ingest  ──▶  sanitize  ──▶  extract  ──▶  enrich  ──▶  map  ──▶  draft
                                          (LLM)        (MCP)      (code)      + URL
```

The terminal state is a saved draft. This service performs no action visible
to a market, a counterparty, or the client. Amendment, cancellation and
submission belong to the existing GUI, reached through the returned URL.

---

## Quick start

```bash
git clone <repo> && cd trade-capture-agent

cp pip.conf.template pip.conf      # set your Nexus URL
./init.sh

source .venv/bin/activate
pytest tests/                      # no model calls
```

Then fill in `.env` (created for you by `init.sh`) before running evals.

**Starting work?** `QUICKSTART.md` — one screen, just the commands.
`docs/first-tasks.md` is the same thing with the reasoning.

`./init.sh` is idempotent. `--check` reports without changing anything;
`--deps-only` skips the AI tooling checks.

---

## Package index

Everything installs from your internal Nexus. Two ways to point at it:

**`pip.conf`** (preferred — machine-local, gitignored):

```bash
cp pip.conf.template pip.conf
$EDITOR pip.conf                   # replace REPLACE-ME.nexus.internal
```

**Environment** (`.env` or shell):

```bash
PIP_INDEX_URL=https://your.nexus.internal/repository/pypi-group/simple
NPM_REGISTRY=https://your.nexus.internal/repository/npm-group/
```

`init.sh` prefers `pip.conf`, falls back to `PIP_INDEX_URL`, and warns if
neither is set rather than quietly reaching for public PyPI.

Version bounds in `requirements.txt` are deliberately loose. Pin them exactly
once you have confirmed which versions your mirror carries.

---

## Layout

```
config/            settings, controlled enum vocabularies
corpus/            eval fixtures, schema, baselines, runs   [CODEOWNERS]
docs/              domain model, corpus spec, workflow, runbook
  proposals/       six drafted changes — import material
  specs-draft/     capability specs to seed openspec/specs/
evals/             corpus runner and tri-state scoring       [CODEOWNERS]
openspec/          created by `openspec init` — not shipped
src/trade_capture/
  domain/          the capture model — tri-state, Quantity union, provenance
  ingestion/       .eml parsing, dedup, the capture reference
  sanitize/        live-region detection, segmentation
  extraction/      the one LLM call, its prompt, its providers
  enrichment/      ordered MCP resolver chain
  mapping/         CaptureModel → OrderRequest, denylist, 256-char budget
  validation/      deterministic post-LLM checks
  clients/         Draft Order client, MCP transport
  api/             sync HTTP entrypoint
tests/
  acceptance/      pre-written criteria, RED by design         [CODEOWNERS]
  unit/ mapper/    agent-written; the green baseline
scripts/           hooks, worktree seeding, labelling helpers
```

### The two schemas

`CaptureModel` is ours and describes **what the client said**.
`OrderRequest` is fixed and owned elsewhere. The LLM only ever produces the
first; code maps to the second.

That split is what lets *"sell all Kyoritsu Maintenance"* work at all. With
one schema, a model facing a required `qty` must invent a number, emit zero,
or fail the message. With two, capture records `EntirePosition` at high
confidence and the mapper declines to fill `orderQty` — which the Draft Order
service accepts, because incomplete drafts are a supported outcome.

### The tri-state

Every field is `Mapped`, `Unmapped`, or `Unresolved`. Never `Optional`.

Turning an `Unmapped` or `Unresolved` into a `Mapped` by inventing a value is
a **fabrication**, and fabrications are gated at zero — a fabricated value
produces a draft that looks complete and correct and is not, with no cue for
a reviewer scanning twenty of them.

---

## Testing and evals

Two layers, deliberately different.

| | Unit + mapper tests | Corpus evals |
|---|---|---|
| Input | `CaptureModel` fixtures | real redacted `.eml` |
| Model | replayed cassettes | **live** |
| Speed | seconds | minutes |
| Runs in CI | yes | yes, gated |

```bash
pytest                              # baseline — green before work starts
pytest -m acceptance                # the target — green before work is done
python -m evals.runner --dev        # 40 dev fixtures, live model
python -m evals.runner --holdout    # the interim 10 — sparingly
```

Acceptance tests are excluded from the default run on purpose: Superpowers
refuses to begin work on a failing baseline, and these are red until their
change lands.

### Cassettes

Evals hit the live model — that is the point of them, and a fake would
measure nothing. But live calls in every unit test make the suite slow,
non-deterministic and expensive, and a suite like that stops getting run.

```bash
TC_LLM_RECORD=1 python -m evals.runner --dev    # record
pytest tests/                                    # replay
```

Cassettes are keyed by prompt hash, so a prompt change invalidates them
rather than replaying stale answers. Re-recording is deliberate and reviewed.

### Gates

| Gate | Threshold |
|---|---|
| Fabrications | **0** — hard block |
| Line recall | **100%** — hard block. A dropped order line is never acceptable |
| Exact match | at or above the committed baseline |
| Misses | within an agreed ceiling — costly, not incorrect |

Line recall is separate because field scoring cannot see a missing order:
three of four lines can score perfectly while a real client order silently
vanishes.

### Splits

`dev` (40) · `holdout` (10) · a second 50 held back entirely.

Check the interim holdout perhaps three times across the whole tuning effort.
Once you have iterated against a split it has stopped being a measurement.
And on 40 fixtures, two emails is 5% — most prompt tweaks that look like a
3-point gain are noise. Chase phenomenon categories in the per-tag breakdown,
not the headline number.

---

## AI tooling

Two tools with overlapping opinions, so the ownership split matters:
**OpenSpec owns intent, Superpowers owns execution.** `docs/workflow.md` has
the full conventions — read it before using either.

### OpenSpec

```bash
npm install -g --registry "$NPM_REGISTRY" @fission-ai/openspec
openspec init
openspec config profile     # choose EXPANDED
openspec update
```

`init` creates `openspec/` and installs `/opsx:` slash commands into Copilot.
This repo ships no `openspec/` directory on purpose — the tool owns its own
layout.

A change lives in `openspec/changes/<name>/` as `.openspec.yaml`,
`proposal.md`, `specs/`, `design.md` and `tasks.md`. State comes from which
artifacts exist and which `tasks.md` boxes are ticked.

**OpenSpec has no approval concept** — it tracks progress, not permission.
So `approval.yaml`, ours, sits alongside and covers only that. The two never
contend over the same field.

Import the six drafts with `/opsx:new <name>`, copy the proposal in, then
`/opsx:ff`. Full sequence in `docs/first-tasks.md`.

### GitHub Copilot CLI

```bash
copilot plugin marketplace add obra/superpowers-marketplace
copilot plugin install superpowers@superpowers-marketplace
```

Behind a proxy, point npm at your Nexus first — Superpowers installs through
the npm-backed marketplace.

**Triggering work.** No slash commands — skills activate on intent, though
naming one is the reliable way to get the pipeline you want. Two lanes:

- **Small change** → `/opsx:apply`. OpenSpec works the `tasks.md` boxes;
  Superpowers' ambient skills (TDD, debugging, verification) still apply.
- **Substantial change** → name `subagent-driven-development` and point it at
  the change directory as its spec. It writes a plan to
  `docs/superpowers/plans/`, creates `.worktrees/<branch>`, then runs one
  task at a time: implementer → task reviewer → fix, and a final
  whole-branch review on the most capable model.

Running both lanes on one change double-tracks progress. Pick one.

**Sequential, not concurrent** — subagents are dispatched one at a time, and
the safety comes from each seeing only its own task. `executing-plans` is the
fallback for environments without subagents, not a parallel mode.

Two things that bite: the **baseline must be green** (acceptance tests are
excluded from the default `pytest` run for exactly this reason), and a
**fresh worktree has no `pip.conf` or `.env`** — run
`scripts/seed-worktree.sh`, or export `PIP_INDEX_URL` in your shell profile
so it follows you in. `docs/workflow.md` has the detail.

`.github/copilot-instructions.md` carries the hard rules and is read
automatically, so they apply whether or not anyone remembers to restate them.

### VS Code

Open the repo and accept the recommended-extensions prompt, or:

```bash
code --install-extension GitHub.copilot --install-extension GitHub.copilot-chat
```

`.vscode/settings.json` enables `useInstructionFiles`, so Copilot Chat in the
editor honours the same rules as the CLI.

---

## Rules that are enforced, not just documented

`CODEOWNERS` and a pre-commit hook back these up.

- **No code without approval.** `approval.yaml` in the change directory,
  naming a human, committed to git. The hook stops an agent writing one.
- **`corpus/` is never edited by an agent.** An agent that can edit an
  expectation can make any test pass, and faced with a red test that is the
  locally rational move. Unprotected fixtures mean the evals measure nothing
  while appearing to pass — worse than having no evals.
- **A failing eval is never fixed by editing a fixture.** Either the code is
  wrong, or the label is wrong (its own PR, reasoning in `notes.md`), or the
  spec is wrong (a new proposal).
- **`openspec/specs/` changes only via `/opsx:sync`** from an approved change.
- **No new dependency without explicit approval.**
- **No sentinel written to mean "unparsed".** `price=0.0` means market-priced.
- **No secret, token or client holding in a prompt, ever.**

---

## Where things are written down

| | |
|---|---|
| `docs/domain-model.md` | Capture schema, field-by-field mapping, validators |
| `docs/corpus-spec.md` | Fixture format, redaction, labelling, scoring, gates |
| `docs/workflow.md` | How proposals become code |
| `docs/first-tasks.md` | Setup, commands, importing the drafts, the loop |
| `docs/specs-draft/` | Numbered, citable requirements — seeds `openspec/specs/` |
| `.github/copilot-instructions.md` | The hard rules, in the agent's context |
