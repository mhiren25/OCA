"""The 256-character execInstructions budget.

NOT IMPLEMENTED - see openspec/changes/002-exec-instructions-budget/proposal.md
Spec: mapping MP-3, MP-4
"""

from __future__ import annotations
