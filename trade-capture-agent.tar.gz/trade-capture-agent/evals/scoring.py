"""Tri-state scoring.

Standard eval scoring assumes a field has a value and asks whether you got it
right. This model has three states, and flattening them into correct/incorrect
discards the distinction the design was built around.

The asymmetry is the whole point:

    a MISS is expensive        - the reviewer does more work
    a FABRICATION is dangerous - the draft looks complete and correct and is
                                 not, and a reviewer scanning twenty drafts
                                 has no cue to look harder at that one

So they are counted and gated separately. A model that misses 20% and never
fabricates is shippable. A model that is 98% accurate with 2% fabrication is
not. Any single accuracy number that lets those trade against each other is
the wrong metric.

Covered by CODEOWNERS: changing what counts as a failure is not a routine edit.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any


class Outcome(StrEnum):
    CORRECT = "CORRECT"
    MISS = "MISS"              # value existed, not found      - costly
    WRONG_VALUE = "WRONG_VALUE"  # found, but different        - critical
    FABRICATION = "FABRICATION"  # invented a value            - critical


CRITICAL = frozenset({Outcome.WRONG_VALUE, Outcome.FABRICATION})


def _state(node: Any) -> str:
    if node is None:
        return "UNRESOLVED"
    kind = node.get("state") if isinstance(node, dict) else None
    return kind or "UNRESOLVED"


def normalise(value: Any) -> Any:
    """Semantic comparison, not textual: "3,900", "3900" and 3900.0 are one
    value; enums compare case-insensitively.

    Quantities and prices compare EXACTLY. There is no tolerance band on an
    order quantity, and a rule that forgives "close enough" on a number that
    becomes a trade is not a rule worth having.
    """
    if isinstance(value, str):
        stripped = value.strip().replace(",", "")
        try:
            return Decimal(stripped)
        except (InvalidOperation, ValueError):
            return value.strip().upper()
    if isinstance(value, float | int):
        return Decimal(str(value))
    return value


def score_field(expected: Any, actual: Any) -> Outcome:
    exp_state, act_state = _state(expected), _state(actual)

    if exp_state in {"UNMAPPED", "UNRESOLVED"}:
        return Outcome.FABRICATION if act_state == "MAPPED" else Outcome.CORRECT

    # expected MAPPED
    if act_state != "MAPPED":
        return Outcome.MISS
    same = normalise(expected.get("value")) == normalise(actual.get("value"))
    return Outcome.CORRECT if same else Outcome.WRONG_VALUE


@dataclass
class FixtureScore:
    fixture: str
    fields: Counter[Outcome] = field(default_factory=Counter)
    lines_expected: int = 0
    lines_found: int = 0
    lines_matched: int = 0
    provenance_failures: int = 0

    @property
    def line_recall(self) -> float:
        """Field scoring cannot see a missing order. Four lines in, three out,
        and every field on those three can be perfect while a real client
        order has silently vanished - the only failure with no downstream cue.
        Gated at 100%."""
        return 1.0 if self.lines_expected == 0 else self.lines_matched / self.lines_expected

    @property
    def line_precision(self) -> float:
        """Guards against phantom orders lifted out of a quoted thread."""
        return 1.0 if self.lines_found == 0 else self.lines_matched / self.lines_found


@dataclass
class RunReport:
    scores: list[FixtureScore] = field(default_factory=list)

    # Pinning - an improvement you cannot attribute is one you cannot keep.
    prompt_version: str = ""
    prompt_hash: str = ""
    schema_version: str = ""
    model: str = ""
    corpus_commit: str = ""

    @property
    def fabrications(self) -> int:
        return sum(s.fields[Outcome.FABRICATION] for s in self.scores)

    @property
    def wrong_values(self) -> int:
        return sum(s.fields[Outcome.WRONG_VALUE] for s in self.scores)

    @property
    def misses(self) -> int:
        return sum(s.fields[Outcome.MISS] for s in self.scores)

    @property
    def exact_match(self) -> float:
        total = sum(sum(s.fields.values()) for s in self.scores)
        correct = sum(s.fields[Outcome.CORRECT] for s in self.scores)
        return 1.0 if total == 0 else correct / total

    @property
    def worst_line_recall(self) -> float:
        return min((s.line_recall for s in self.scores), default=1.0)

    def gate(self, *, min_exact_match: float) -> list[str]:
        """Hard gates first. Returns the reasons a run fails, empty if it passes."""
        failures: list[str] = []
        if self.fabrications:
            failures.append(f"{self.fabrications} fabrication(s) - budget is zero")
        if self.wrong_values:
            failures.append(f"{self.wrong_values} wrong value(s)")
        if self.worst_line_recall < 1.0:
            failures.append(f"line recall {self.worst_line_recall:.0%} - an order was dropped")
        if self.exact_match < min_exact_match:
            failures.append(
                f"exact match {self.exact_match:.1%} below baseline {min_exact_match:.1%}"
            )
        return failures
