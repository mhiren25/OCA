"""Name / Bloomberg ticker / code -> ISIN, venue, currency. reasoning_required = True: fuzzy names yield candidates that need judgement.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
