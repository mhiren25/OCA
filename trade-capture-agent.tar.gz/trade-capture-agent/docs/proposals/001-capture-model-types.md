<!-- draft proposal · import with /opsx:new 001-capture-model-types then /opsx:ff
     spec: capture-model -->

# 001-capture-model-types

## Why

Everything downstream types against the capture model, so nothing else can be
built until it exists. It also carries the one decision that makes the rest of
the system possible.

Two of our sample emails are:

    "Please sell all (91,647) shares of Sunrise Energy Metals at vwap over the day."
    "Please sell all Kyoritsu Maintenance at vwap over the day."

They differ by one parenthesis. With `quantity: float` the second email forces
the extractor to invent a number, emit zero, or fail the message — there is
nowhere to record "the client said ALL and gave no figure". A union makes that
a representable state, and the Draft Order service accepts the resulting
incomplete draft.

The same argument applies field-wide. `Optional[T]` cannot distinguish "the
client didn't say" from "the client said something we can't express", and
those need different handling: one is completed by a reviewer, the other must
reach the trader as text.

## What changes

Three new modules, no behaviour yet.

`domain/provenance.py`
- `SourcePart` enum: BODY_TEXT, BODY_HTML, SUBJECT, ATTACHMENT, EMBEDDED_IMAGE
- `Provenance`: part, start, end, optional attachment_name and excerpt
- `Provenance.contains(needle, source) -> bool` — whether the span really
  holds the claimed value

`domain/states.py`
- `Mapped[T]`: value, provenance, confidence (0.0–1.0)
- `Unmapped`: raw_text, provenance, reason, priority (0–100, default 50)
- `UnmappedReason`: NO_TARGET_FIELD, NO_VALID_ENUM, AMBIGUOUS
- `Unresolved`: optional raw_text and provenance
- `Field3 = Mapped[T] | Unmapped | Unresolved`
- `is_fabricated(expected, actual) -> bool` — a Mapped produced where the
  label says Unmapped or Unresolved

`domain/quantity.py`
- `Absolute`: value (> 0), provenance
- `EntirePosition`: optional client_asserted, optional resolved_position,
  provenance
- `PositionSnapshot`: quantity, as_of, source — `as_of` is **required**
- `UnresolvedQuantity`: raw_text, optional provenance
- `Quantity = Absolute | EntirePosition | UnresolvedQuantity`

Pydantic v2 models throughout, `from __future__ import annotations`, full
type hints.

## Out of scope

`OrderIntent` and `CaptureEnvelope` — they compose these and come with the
extraction work. No parsing, no mapping, no serialisation format.

## Acceptance

- All three modules import cleanly and construct under Pydantic v2.
- `Absolute(value=0)` and negative values are rejected.
- `EntirePosition` is constructible with client_asserted set, with it unset,
  and with both it and resolved_position unset. All three are valid — they are
  the Sunrise case, the Kyoritsu case, and the Phase 2 case respectively.
- `PositionSnapshot` cannot be constructed without `as_of`.
- `is_fabricated` is True for (Unmapped, Mapped) and (Unresolved, Mapped), and
  False for (Mapped, Mapped) and every pairing where actual is not Mapped.
- `Provenance.contains` returns False when the span does not hold the value.
- `priority` outside 0–100 and `confidence` outside 0.0–1.0 are rejected.
- New unit tests in `tests/unit/` covering the above.

## Risks

Over-modelling. Add only what this proposal lists — fields "we'll probably
need" are how a schema becomes hard to change. `client_asserted` and
`resolved_position` staying independent is load-bearing: when both are present
and disagree, both must survive to the reviewer. Collapsing them into one
field destroys the most valuable signal the system produces.
