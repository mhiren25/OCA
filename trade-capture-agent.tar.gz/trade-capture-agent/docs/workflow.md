# Workflow — how a change becomes code

Two tools with overlapping opinions, so the first job is deciding which owns
what. Without that decision you get two answers to "what is the current
task" and spend the project reconciling them.

> **OpenSpec owns intent. Superpowers owns execution.**

| | OpenSpec | Superpowers |
|---|---|---|
| Unit | A change: `openspec/changes/<name>/` | A plan task (one commit) |
| Human-reviewed? | **Yes — `approval.yaml` is the gate** | No |
| Durable? | Yes → `changes/archive/` | No — regenerate freely |
| Answers | *Should this be built, and what is it* | *How it gets built* |

---

## The loop

```
  1  NEW + FF    /opsx:new, /opsx:ff       proposal, specs, design, tasks
       |
  2  REVIEW      a person reads it         <-- THE GATE
       |
  3  APPROVE     approval.yaml             a human, recorded in git
       |
  4  BUILD       lane A or lane B          see below
       |
  5  VERIFY      pytest -m acceptance + /opsx:verify
       |
  6  SYNC        /opsx:sync                delta specs → main specs
       |
  7  ARCHIVE     /opsx:archive             changes/archive/YYYY-MM-DD-<name>/
```

Nothing at step 4 starts without step 3 having happened.

---

## Two build lanes

`/opsx:apply` and Superpowers' subagent pipeline **both** want to be the
thing that drives implementation. Running both at once double-tracks
progress. Pick a lane per change.

### Lane A — `/opsx:apply` · small, mechanical changes

```
/opsx:apply
```

OpenSpec works the `tasks.md` checkboxes. Superpowers' ambient skills still
fire — TDD, systematic debugging, verification-before-completion — but there
is no separate plan file and no subagent pipeline.

Good for: one or two files, a complete spec, an hour of work. Changes 002,
004 and 005 are lane A.

### Lane B — subagent-driven development · substantial changes

Superpowers' `writing-plans` says a plan **implements a single spec
document**. The OpenSpec change directory *is* that document. So:

```
Use subagent-driven-development to implement
openspec/changes/008-sanitize-live-region/.

The change directory is the spec: read proposal.md, specs/ and design.md.
Copy the global constraints from .github/copilot-instructions.md into the
plan header. Acceptance tests in tests/acceptance/ are read-only.
```

What that actually does:

1. **`writing-plans`** produces `docs/superpowers/plans/YYYY-MM-DD-<name>.md`
   — a header (goal, architecture, tech stack, link to the spec, global
   constraints copied verbatim), a file-structure map, then bite-sized tasks.
   Each task names its **files**, its **interfaces** (what it consumes from
   earlier tasks and produces for later ones, with signatures), and five
   micro-steps: *write failing test → verify it fails → implement → verify it
   passes → commit*.

2. **`using-git-worktrees`** creates `.worktrees/<branch>` and installs
   dependencies there.

3. **`subagent-driven-development`** runs the pipeline, one task at a time:

   ```
   task-brief → implementer → review-package → task reviewer
                    ↑                                |
                    └──────── fix subagent ←─────────┘ (until clean)
   ```

   Each subagent gets **only its own task** — no session history, no other
   tasks. Isolation is what makes it safe. The task reviewer returns two
   verdicts: *spec compliance* (does it match the brief — gaps or extras?)
   and *code quality* (well built, tests cover it, project rules honoured).
   A line lands in the ledger, then the next task starts.

4. **Final whole-branch review** on the most capable model, over the full
   merge-base diff plus every per-task finding.

Good for: multi-file work, anything with real design content, anything where
you want a review trail. Changes 001, 007, 008 and 010 are lane B.

### It is sequential, not concurrent

A common misreading, and I made it myself: subagent-driven-development
dispatches subagents **one at a time**. The safety comes from each subagent
seeing only its own task, not from running them in parallel. Never dispatch
multiple implementers at once.

`executing-plans` is not the parallel alternative either — it is the
*fallback* for environments without subagent support. Real parallelism means
separate sessions on separate branches, which for this project means two
independent changes, not two tasks in one change.

### Specify the model on every dispatch

An omitted model inherits the session default and quietly defeats cost
control. Superpowers' own guidance is that turn count beats token price —
a cheap model on multi-step work takes 2–3× the turns and costs more.

| Work | Model |
|---|---|
| Mechanical: 1–2 files, complete spec | cheapest |
| Integration: multi-file, prose spec | standard |
| Architecture, and **every final review** | most capable |

For this project the final reviewer is always the most capable model. It is
the last thing standing between an agent and the deny-list.

---

## Where Superpowers puts things

| Path | What | Committed? |
|---|---|---|
| `docs/superpowers/plans/YYYY-MM-DD-<name>.md` | The plan | **Yes** — it records how a change was built |
| `.worktrees/<branch>/` | Isolated workspace | No — gitignored, and Superpowers *requires* that |
| `.superpowers/sdd/progress.md` | Task ledger, for resume | No — per-machine session state |

Resume after a break: `cat .superpowers/sdd/progress.md`. Completed tasks are
listed; work resumes at the first unmarked one.

The plan is committed but is **not a governance artifact**. Nobody approves a
plan. If it comes out wrong, regenerate it. If the *intent* was wrong, that
is a new change.

---

## Two things that will bite you

### The baseline must be green

Superpowers checks that tests pass before starting, and refuses to build on
a failing baseline. Our acceptance tests are **red by design** — they are
pre-written criteria for work not yet done.

Resolved in `pyproject.toml`: the default run excludes them.

```bash
pytest                  # baseline — green before work starts
pytest -m acceptance    # the target — green before work is done
```

If you ever remove that marker exclusion, Superpowers will refuse to start on
a clean checkout and the reason will be baffling.

### A fresh worktree has no Nexus config

`using-git-worktrees` auto-runs `pip install -r requirements.txt` in each new
worktree. But `pip.conf` and `.env` are gitignored, so a new worktree has
neither — and the install reaches for public PyPI, which fails behind Nexus.

```bash
scripts/seed-worktree.sh .worktrees/<branch>
```

Better: export `PIP_INDEX_URL` and `NPM_REGISTRY` in your shell profile.
Environment variables follow you into every worktree; files do not.

---

## Why `approval.yaml` exists

OpenSpec tracks a change by which artifacts exist and which task boxes are
ticked. That is **progress**, not **permission** — "three of eight tasks
done" says nothing about whether a human agreed the work should happen. For
a service that writes into a trading platform, that distinction is the whole
control.

So approval lives in a file OpenSpec does not own, covering only that:

```yaml
approved_by: shreya      # never an agent
approved_at: 2026-09-11
proposal_sha:            # optional — approval is of a specific version
notes:                   # what you changed before approving
```

An agent may draft a proposal. An agent must never write `approval.yaml`.

### What the hook can and cannot do

A git hook fires at commit time, so it cannot stop `/opsx:apply` or a
subagent from *running*. What it does is stop an agent **forging** the
approval that authorises the work, and stop it editing what measures the
work. The gate itself is procedural: you do not start step 4 until
`approval.yaml` exists.

Worth stating plainly rather than implying the enforcement is tighter than
it is.

---

## Boundaries

CODEOWNERS and the pre-commit hook, not good intentions.

| Path | Rule |
|---|---|
| `corpus/fixtures/`, `corpus/baselines/`, `corpus/schema/` | **Never** edited by an agent |
| `evals/scoring.py`, `tests/acceptance/` | **Never** edited by an agent |
| `openspec/changes/*/approval.yaml` | **Never** written by an agent |
| `openspec/specs/` | Changes only via `/opsx:sync` |
| `src/.../mapping/denylist.py` | Human review required |
| `requirements*.txt` | New dependencies need explicit approval |
| `.github/`, CI config | Human review required |

**The corpus rule is the important one.** Faced with a red test, editing the
expectation is the locally rational move and an agent will find it. If the
fixtures are not protected the evals measure nothing — and they will appear
to pass while measuring nothing, which is strictly worse than having none.

A failing test means the code is wrong (fix the code), the label is wrong
(its own PR, with reasoning), or the spec is wrong (a new change). Never a
quiet fixture edit.

---

## Scope signals

A task touching 30 files was mis-planned. Regenerate the plan rather than
reviewing the diff — plans are cheap, and a sprawling diff is where mistakes
get waved through.

When a task reviewer says *"⚠️ Cannot verify from diff"*, it is flagging a
requirement that lives in code this task did not touch. That is yours to
resolve with cross-task context the reviewer does not have — don't wave it
through as a pass.

---

## Commands

```bash
alias tc-changes='openspec list'
alias tc-state='openspec status --change'      # tc-state 001-... --json
alias tc-approved='ls openspec/changes/*/approval.yaml 2>/dev/null'
alias tc-plans='ls docs/superpowers/plans/'
alias tc-ledger='cat .superpowers/sdd/progress.md'
alias tc-base='pytest -q'                      # baseline: must be green
alias tc-target='pytest -m acceptance -q'      # the change's criteria
alias tc-check='pytest -q && ruff check . && mypy src/'
alias tc-eval='python -m evals.runner --dev'
```

---

## What this deliberately is not

Not a framework. One extra file, a directory convention, a CODEOWNERS list, a
hook and a seed script. OpenSpec already has a change lifecycle; Superpowers
already has planning, worktrees, subagent dispatch and layered review.
Rebuilding either produces an orchestration layer that duplicates one of them
and then fights it on every upgrade.

If this document grows past three pages, something has gone wrong.
