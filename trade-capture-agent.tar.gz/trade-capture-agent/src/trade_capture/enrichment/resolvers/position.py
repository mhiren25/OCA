"""Phase 2. (account, instrument) -> holding. reasoning_required = False: a keyed lookup with one right answer.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
