"""Everything here is an acceptance test, marked automatically.

These are RED by design until the change that implements them lands.
Superpowers will not begin work on a failing baseline, so they are excluded
from the default `pytest` run and asserted explicitly instead:

    pytest                  baseline — must be green before work starts
    pytest -m acceptance    the target — must be green before work is done
"""

from __future__ import annotations

import pytest


def pytest_collection_modifyitems(items) -> None:
    for item in items:
        item.add_marker(pytest.mark.acceptance)
