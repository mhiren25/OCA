# Spec: Corpus and evals

## Purpose
Measure extraction quality, and make regressions visible before merge.

## Requirements

- **CO-1** Fixtures are labelled at **capture level**, never payload level.
  Client intent is stable; the mapping churns.
- **CO-2** Fixtures hold the original redacted `.eml`, never pasted text.
- **CO-3** Redaction preserves structure, noise and formatting exactly.
  Instruments, quantities and prices stay real.
- **CO-4** Scoring distinguishes correct / miss / wrong value / fabrication.
  Fabrications and wrong values are critical; misses are costly.
- **CO-5** Line recall and line precision are scored separately from fields.
  Field scoring cannot see a dropped order.
- **CO-6** Gates: fabrications 0 (hard), line recall 100% (hard), exact match
  at or above baseline, misses within an agreed ceiling.
- **CO-7** Every run pins prompt version and hash, schema version, model ID
  and corpus commit.
- **CO-8** Negative fixtures (no order present) are 15–20% of the corpus.
- **CO-9** `corpus/` is CODEOWNERS-protected. A failing test is never fixed by
  editing a fixture.
- **CO-10** Baselines move only in a deliberate commit with a human rationale.

## Splits
`dev` (40) · `holdout` (10, checked sparingly) · a second 50 held back
entirely as the final holdout.
