"""Corpus eval runner.

    python -m evals.runner --dev        the 40 dev fixtures
    python -m evals.runner --holdout    the interim 10 - use sparingly

Runs against the LIVE model: that is the point of an eval, and a fake would
measure nothing. Set TC_LLM_RECORD=1 to also write cassettes for the unit
tests to replay.

On the holdout: check it perhaps three times over the whole tuning effort.
Every look costs a little of its independence, and once the dev split has
been iterated against it has stopped being a measurement.
"""

from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="evals.runner")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--dev", action="store_true", help="dev split")
    group.add_argument("--holdout", action="store_true", help="interim holdout - sparingly")
    group.add_argument("--all", action="store_true", help="everything (final runs only)")
    group.add_argument("--fixture", help="a single fixture by directory name")
    parser.add_argument("--tag", action="append", help="filter by phenomenon tag")
    parser.add_argument("--min-exact-match", type=float, default=None)
    parser.parse_args(argv)

    # TODO(spec: corpus): load fixtures, run extraction, score, write
    # runs/<ts>-<prompt-hash>/report.json, apply gates, exit non-zero on fail.
    print("not implemented - see openspec/specs/corpus/spec.md", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
