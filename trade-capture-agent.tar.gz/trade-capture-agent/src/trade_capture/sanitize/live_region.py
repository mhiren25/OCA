"""Decide which part of a thread is the live instruction and which is history. Getting this wrong re-books last week's orders.

TODO: see openspec/specs/ for the specification this implements.
"""

from __future__ import annotations
